package com.jpr_hrms;

public class Constans {

    public static final String EmpID = "empId";
}
